// import React from 'react'

// const Protected = ({Component}) => {
//   return (
//     if()
//     <div>Protected</div>
//   )
// }

// export default Protected