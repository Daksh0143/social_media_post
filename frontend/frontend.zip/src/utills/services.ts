export const parseUserData = (data: string) => {
  return JSON.parse(data);
};
