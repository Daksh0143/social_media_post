import { useEffect, useState } from "react";
import "./App.css";
import Register from "./Component/Resgister";
import { BrowserRouter as Router, Routes, Route, json } from "react-router-dom";
import Login from "./Component/Login";
import Navbar from "./Component/Navbar";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import mockData from "./Constant/MOCK_DATA.json";
import Home from "./Component/Home";
import CreatePost from "./Component/CreatePost";
function App() {
  const [count, setCount] = useState(0);

  return (
    <div style={{ height: "100dvh" }}>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/home" element={<Home />} />
          <Route path="/create-post" element={<CreatePost />} />
        </Routes>
      </Router>
      <ToastContainer position="top-right" />
    </div>
  );
}

export default App;
