import { Button, Grid, Typography } from "@mui/material";
import React, { useEffect } from "react";
import CommonButton from "../Common/CommonButton";
import Textarea from "@mui/joy/Textarea";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import { useSelector, useDispatch } from "react-redux";
import { getPost } from "../redux/post/postMiddleware";

const Home = () => {
  const navigate = useNavigate();

  // const { isLoading, isError, data } = useSelector((state: any) => state.Post);
  // const dispatch = useDispatch();

  // console.log("Is Loading",isLoading),
  // console.log("Error",isError)
  // console.log("Data",data)

  // useEffect(() => {
  //   dispatch(getPost("postId"));
  // }, [dispatch]);

  return (
    <Grid container>
      <Grid
        container
        spacing={2}
        sx={{
          padding: "10px",
          position: "relative",
        }}
      >
        <Grid
          item
          xs={12}
          md={4}
          mt={1}
          mr={1}
          sx={{ position: "absolute", top: "10px", right: "10px" }}
        >
          <CommonButton
            variant="contained"
            color="success"
            size="large"
            sx={{
              display: "flex",
              paddingTop: "10px",
              flexDirection: "row-reverse",
            }}
            title="Create New"
            onClick={() => navigate("/create-post")}
          />
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        bgcolor={"white"}
        sx={{
          position: "absolute",

          top: "180px",
          border: "2px solid yellow",
          padding: "20px",
        }}
      >
        <Grid
          item
          xs={12}
          md={10}
          lg={12}
          sx={{ bgcolor: "black", color: "white" }}
        >
          <Typography
            variant="body2"
            p={0.5}
            sx={{
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
            }}
          >
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda quasi qui ipsum eius quos eveniet odit possimus. Nobis natus asperiores nesciunt omnis obcaecati ex recusandae veritatis velit itaque voluptas possimus beatae perspiciatis facere nostrum, culpa voluptatum nam officiis iste quos. Quaerat dolorem, aliquam, quia perspiciatis odit maiores doloribus harum itaque officiis provident facilis praesentium explicabo? Officiis, debitis. Ad, officiis magnam ipsam quis deleniti consequuntur illo architecto quod vel, alias at? Illo laborum in at minus quidem consequuntur a doloremque quisquam, beatae necessitatibus laudantium delectus ipsa esse velit inventore, quia vel.
          </Typography>
        </Grid>

        <Grid
          container
          spacing={2}
          sx={{ justifyContent: "center", alignItems: "center" }}
        >
          <Grid item xs={12} md={6}>
            <CommonButton
              title="like"
              variant="contained"
              size="large"
              color="success"
              sx={{ margin: "20px" }}
            />
            <CommonButton
              title="like"
              variant="contained"
              size="large"
              color="success"
              sx={{ margin: "20px" }}
            />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Home;
