import { createSlice } from "@reduxjs/toolkit";
import { userRegistrationAction, userLoginAction } from "./auth.middleware";

export const authSlice = createSlice({
  name: "Auth",
  initialState: {
    isLoading: false,
    isError: false,
    data: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(userRegistrationAction.fulfilled, (state, { payload }) => {
        (state.isLoading = false),
          (state.isError = false),
          (state.data = payload);
      })
      .addCase(userRegistrationAction.pending, (state, { payload }) => {
        (state.isLoading = true), (state.isError = false);
      }),
      builder.addCase(userRegistrationAction.rejected, (state, { payload }) => {
        (state.isLoading = true), (state.isError = true);
      });
    //Login Action
      builder.addCase(userLoginAction.fulfilled, (state, { payload }) => {
        (state.isLoading = false), (state.isError = false);
        state.data = payload;
      });
    builder.addCase(userLoginAction.pending, (state, { payload }) => {
      state.isLoading = true;
      state.isError = false;
    });
    builder.addCase(userLoginAction.rejected, (state, { payload }) => {
      state.isLoading = true;
      state.isError = true;
    });
  },
});
