import { AsyncThunk, createAsyncThunk } from "@reduxjs/toolkit";
import { createPost,getAllPost} from "../post/postServices";
import { toast } from "react-toastify";

export const postADetails: AsyncThunk<any, any, {}> = createAsyncThunk<
  any,
  any
>("post/create/post", async (request, { rejectWithValue }) => {
  try {
    const response = await createPost(request);
    console.log("Response", response);
    if (response?.status === 201 || response?.status === 200) {
      console.log("Response", response);
      return response;
    }
    console.log("Rejected With response", response);
    return rejectWithValue(response);
  } catch (error: any) {
    console.log("Errror", error);
    return rejectWithValue(error?.response?.data?.message);
  }
});

// export const getPost: AsyncThunk<any, any, {}> = createAsyncThunk<any, any>(
//   "post/getAll",
//   async (postId, { rejectWithValue }) => {
//     console.log("PostId",postId);
    
//    try {
//       const data=await getAllPost(postId);
//       console.log("Dataa",data);
//       return data
//    } catch (error:any) {
//       console.log("Error",error)
//       return rejectWithValue(error?.response?.data?.message)
//    }
//   }
// );
