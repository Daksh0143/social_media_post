import axios from "axios";
import api from "../api";

import { toast } from "react-toastify";

const PostUrl = "post/create";
const GetPostUrl="post/getAll";

interface post{
  title:String,
  description:String

}

export const createPost = async (request: post) => {
  try {
    console.log("createPost : " , request)
    console.log("Request",request)
    const response = await api.post(PostUrl, request);
    console.log("Response",response)
    return response;
  } catch (error: any) {
    console.log("Error", error);
    return error.response;
  }
};


export const getAllPost=async(postId:any)=>{
    const response=await api.get(`${GetPostUrl}/${postId}`)
    console.log("Response gettting",response)
    return response.data as any[]
}