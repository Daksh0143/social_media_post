import { createSlice } from "@reduxjs/toolkit";
import { postADetails,getPost } from "../post/postMiddleware";

export const postSlice = createSlice({
  name: "post",
  initialState: {
    isLoading: false,
    isError: false,
    data: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(postADetails.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.isError = false;
        state.data = payload;
        console.log({ payload }, "Payload");
      })
      .addCase(postADetails.pending, (state, { payload }) => {
        state.isLoading = true;
        state.isError = false;
        console.log("Payload", payload);
      })
      .addCase(postADetails.rejected, (state, { payload }) => {
        (state.isLoading = false), (state.isError = true);
      })

      //Get a Post
      // .addCase(getPost.fulfilled, (state, { payload }) => {
      //   (state.isLoading = false),
      //     (state.isError = false),
      //     (state.data = payload);
      // })
      // .addCase(getPost.pending, (state, { payload }) => {
      //   state.isLoading = true;
      //   state.isError = false;
      //   console.log("Payload", payload);
      // })
      // .addCase(getPost.rejected, (state, { payload }) => {
      //   (state.isLoading = false), (state.isError = true);
      // });
  },
});
